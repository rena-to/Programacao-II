from django.contrib import admin
from django.urls import path
from django.urls import re_path as url
from carro import views

urlpatterns = [
    path('carro/', admin.site.urls),
    url(r'^$', views.index)

]